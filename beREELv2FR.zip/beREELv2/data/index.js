import {registerUser, loginUser} from './userData.js'

const userData =  {
    registerUser,
    loginUser
};
  

export {userData};